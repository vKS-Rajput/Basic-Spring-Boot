package com.autowiring;

public class Car {
    Specification specification;

    public void setSpecification(Specification specification) {
        this.specification = specification;
    }

    public  void DisplayDetails(){
        System.out.println("Details:- " + specification.toString());
    }
}
