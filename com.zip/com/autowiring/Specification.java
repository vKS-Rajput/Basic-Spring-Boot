package com.autowiring;

public class Specification {
    private  String Name;
    private String Model;
    private String Tyre;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        Model = model;
    }

    public String getTyre() {
        return Tyre;
    }

    public void setTyre(String tyre) {
        Tyre = tyre;
    }

    @Override
    public String toString() {
        return "Specification{" +
                "Name='" + Name + '\'' +
                ", Model='" + Model + '\'' +
                ", Tyre='" + Tyre + '\'' +
                '}';
    }
}
