package com.IOC.coupling;

public interface GetData {
    String getUserInfo();


}
