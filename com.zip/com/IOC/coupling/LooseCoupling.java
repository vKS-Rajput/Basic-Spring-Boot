package com.IOC.coupling;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LooseCoupling {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationIOCcoupling.xml");

//        UserDataProvider userDataProvider = new UserDataProvider(userDatabseProvider);
        UserDataProvider userDataProvider = (UserDataProvider) context.getBean("userDataProviderWithDatabse") ;
        System.out.println(userDataProvider.getUserInfo());

//        GetData webServiceDataProvider = new WebServiceDataProvider();

//        UserDataProvider webDataProvider = new UserDataProvider(webServiceDataProvider);
        UserDataProvider webDataProvider = (UserDataProvider) context.getBean("userDataProviderWithWebService") ;
        System.out.println(webDataProvider.getUserInfo());

    }
}
