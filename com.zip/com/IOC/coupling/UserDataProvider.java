package com.IOC.coupling;

public class UserDataProvider {
    private GetData getData;

    public UserDataProvider(GetData getData) {
        this.getData = getData;
    }
    public  String getUserInfo(){
        return getData.getUserInfo();
    }
}
