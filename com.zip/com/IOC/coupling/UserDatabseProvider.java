package com.IOC.coupling;

public class UserDatabseProvider implements GetData {
    public  String getUserInfo() {
        return "Data Recieved Successfully";
    }
}
