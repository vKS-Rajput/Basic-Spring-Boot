package com.IOC.coupling;

public class WebServiceDataProvider implements GetData {
    @Override
    public String getUserInfo() {
        return "Fetching Data from Databse";
    }
}
