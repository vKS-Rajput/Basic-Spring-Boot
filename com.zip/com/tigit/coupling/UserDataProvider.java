package com.tigit.coupling;

public class UserDataProvider {
    UserDataBaseProvider userDataProvider = new UserDataBaseProvider();

    public String getUserDataProvider() {
        return userDataProvider.getUserDetails();
    }
}
