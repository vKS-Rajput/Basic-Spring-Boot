package com.tigit.coupling;

public class TightCoupline {



     public static  void main(String[] args) {
         UserDataProvider userDataProvider = new UserDataProvider();
         System.out.println(userDataProvider.getUserDataProvider());
    }
}
