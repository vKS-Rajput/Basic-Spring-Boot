package com.tigit.coupling;

public class UserDataBaseProvider {
    public String getUserDetails(){
        return "Data Recieved from Dtabase";
    }
}
