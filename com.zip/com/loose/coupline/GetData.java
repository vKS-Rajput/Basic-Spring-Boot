package com.loose.coupline;

public interface GetData {
    String getUserInfo();


}
