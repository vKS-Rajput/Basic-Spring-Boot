package com.loose.coupline;

public class UserDatabseProvider implements GetData{
    public  String getUserInfo() {
        return "Data Recieved Successfully";
    }
}
