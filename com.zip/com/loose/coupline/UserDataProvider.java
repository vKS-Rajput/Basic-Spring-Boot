package com.loose.coupline;

import com.tigit.coupling.UserDataBaseProvider;

public class UserDataProvider {
    private  GetData getData;

    public UserDataProvider(GetData getData) {
        this.getData = getData;
    }
    public  String getUserInfo(){
        return getData.getUserInfo();
    }
}
