package com.loose.coupline;

public class LooseCoupling {
    public static void main(String[] args) {
        UserDatabseProvider userDatabseProvider = new UserDatabseProvider();

        UserDataProvider userDataProvider = new UserDataProvider(userDatabseProvider);
        System.out.println(userDataProvider.getUserInfo());

        GetData webServiceDataProvider = new WebServiceDataProvider();
        UserDataProvider webDataProvider = new UserDataProvider(webServiceDataProvider);
        System.out.println(webDataProvider.getUserInfo());

    }
}
